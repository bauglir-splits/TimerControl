#!/bin/bash

python3 -m venv environment
environment/bin/pip3 install keyboard requests