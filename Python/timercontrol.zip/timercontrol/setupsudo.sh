#!/bin/bash

sudo ./setup.sh
