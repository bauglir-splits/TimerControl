#!/bin/bash

#sudo environment/bin/python timercontrol.py
sudo ./run.sh
